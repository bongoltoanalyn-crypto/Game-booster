package com.bossbooster.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku

private val Bg = Color(0xFF0B0B0D)
private val Panel = Color(0xFF17171B)
private val Red = Color(0xFFFF3038)
private val Muted = Color(0xFFAAAAB3)
private const val SHIZUKU_REQUEST_CODE = 4242

data class LaunchableApp(val label: String, val packageName: String)
data class DeviceStats(
    val batteryPercent: Int,
    val batteryTempC: String,
    val availableRamMb: Long,
    val totalRamMb: Long,
    val thermalStatus: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BossBoosterApp(this) }
    }
}

@Composable
private fun BossBoosterApp(context: MainActivity) {
    var selectedTab by remember { mutableStateOf("HOME") }
    var boostMessage by remember { mutableStateOf("Prepare your phone for a gaming session") }
    var refreshCounter by remember { mutableIntStateOf(0) }
    var shizukuStatus by remember { mutableStateOf("Checking Shizuku…") }
    var overlayStatus by remember { mutableStateOf("Overlay permission not checked") }

    fun updateShizukuStatus() {
        shizukuStatus = try {
            if (!Shizuku.pingBinder()) "Shizuku is not running"
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) "Shizuku permission granted"
            else "Shizuku is running; permission needed"
        } catch (_: Exception) {
            "Shizuku API unavailable"
        }
    }

    LaunchedEffect(Unit) { updateShizukuStatus() }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red, background = Bg, surface = Panel,
            onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(46.dp).background(Red, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Speed, contentDescription = null, tint = Color.White)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("BOSS BOOSTER", fontSize = 22.sp, fontWeight = FontWeight.Black)
                        Text("GAME PERFORMANCE CENTER", color = Muted, fontSize = 10.sp, letterSpacing = 1.4.sp)
                    }
                    IconButton(onClick = { refreshCounter++; updateShizukuStatus() }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh", tint = Red)
                    }
                }

                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("HOME", "GAMES", "VOICE", "ULTIMATE").forEach { tab ->
                        FilterChip(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            label = { Text(tab) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Red, selectedLabelColor = Color.White)
                        )
                    }
                }

                when (selectedTab) {
                    "HOME" -> HomeContent(stats = remember(refreshCounter) { getDeviceStats(context) }, message = boostMessage) {
                        boostMessage = "Checklist complete. Close unused apps if you need more free memory."
                    }
                    "GAMES" -> GamesContent(context, remember(refreshCounter) { getLaunchableApps(context) })
                    "VOICE" -> VoiceChangerContent(context)
                    else -> UltimateContent(
                        context = context,
                        shizukuStatus = shizukuStatus,
                        overlayStatus = overlayStatus,
                        onRefreshShizuku = { updateShizukuStatus() },
                        onRequestShizuku = {
                            try {
                                if (Shizuku.pingBinder()) {
                                    if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                                        shizukuStatus = "Shizuku permission already granted"
                                    } else {
                                        Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
                                        shizukuStatus = "Permission request sent — approve it in Shizuku"
                                    }
                                } else {
                                    shizukuStatus = "Start Shizuku first, then tap Check again"
                                }
                            } catch (_: Exception) {
                                shizukuStatus = "Shizuku unavailable; install/start Shizuku first"
                            }
                        },
                        onOverlay = {
                            if (Settings.canDrawOverlays(context)) {
                                context.startService(Intent(context, GamingOverlayService::class.java))
                                overlayStatus = "Overlay started"
                            } else {
                                overlayStatus = "Allow display over other apps in Android Settings"
                                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                                context.startActivity(intent)
                            }
                        },
                        onOpenShizukuGuide = {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/")))
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeContent(stats: DeviceStats, message: String, onBoost: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            Column(
                Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF321014), Panel)), RoundedCornerShape(24.dp)).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("READY TO PLAY?", color = Muted, fontSize = 12.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(14.dp))
                Box(Modifier.size(148.dp).background(Red, CircleShape).padding(5.dp).background(Color(0xFF1B090B), CircleShape), contentAlignment = Alignment.Center) {
                    Button(onClick = onBoost, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.size(118.dp)) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.Speed, contentDescription = null, modifier = Modifier.size(30.dp))
                            Text("BOOST", fontWeight = FontWeight.Black, fontSize = 18.sp)
                            Text("NOW", fontSize = 11.sp)
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text(message, color = Color(0xFFFF7378), fontSize = 13.sp)
                Text("Checklist only; no guaranteed FPS or overclocking.", color = Muted, fontSize = 10.sp)
            }
        }
        item {
            Text("DEVICE STATUS", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatusCard("BATTERY", "${stats.batteryPercent}%", Icons.Filled.BatteryChargingFull, Modifier.weight(1f))
                StatusCard("FREE RAM", "${stats.availableRamMb} MB", Icons.Filled.Memory, Modifier.weight(1f))
            }
        }
        item {
            Text("THERMAL STATUS", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.height(8.dp))
            Text(stats.thermalStatus, color = Muted, fontSize = 13.sp)
            Text("Battery temperature: ${stats.batteryTempC}", color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
private fun GamesContent(context: Context, apps: List<LaunchableApp>) {
    var search by remember { mutableStateOf("") }
    val filtered = apps.filter { it.label.contains(search, ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Text("GAME CHANGER", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Launcher list of apps with launch activities; Android may hide some apps.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, label = { Text("Search installed apps") },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Red, focusedLabelColor = Red, cursorColor = Red)
        )
        Spacer(Modifier.height(8.dp))
        if (filtered.isEmpty()) {
            Text("No launchable apps found.", color = Muted, modifier = Modifier.padding(16.dp))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(filtered, key = { it.packageName }) { app ->
                    Row(
                        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable {
                            context.packageManager.getLaunchIntentForPackage(app.packageName)?.let {
                                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                context.startActivity(it)
                            }
                        }.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Gamepad, contentDescription = null, tint = Red, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(app.label, fontWeight = FontWeight.SemiBold)
                            Text(app.packageName, color = Muted, fontSize = 10.sp)
                        }
                        Text("OPEN", color = Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}


@Composable
private fun VoiceChangerContent(context: MainActivity) {
    var selectedEffect by remember { mutableStateOf("Robot") }
    var status by remember {
        mutableStateOf(
            if (context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                "Microphone permission granted"
            else "Microphone permission not granted"
        )
    }
    val hasMicPermission = context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val androidVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF321014), Panel)), RoundedCornerShape(22.dp)).padding(18.dp)) {
                Text("BOSS VOICE CHANGER", color = Red, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Spacer(Modifier.height(6.dp))
                Text("LIVE MIC COMPATIBILITY", color = Muted, fontSize = 11.sp, letterSpacing = 1.3.sp)
                Spacer(Modifier.height(10.dp))
                Text("Choose an effect profile", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                listOf("Robot", "Deep Voice", "Alien", "High Pitch").chunked(2).forEach { rowEffects ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowEffects.forEach { effect ->
                            FilterChip(
                                selected = selectedEffect == effect,
                                onClick = { selectedEffect = effect },
                                label = { Text(effect) },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Red, selectedLabelColor = Color.White)
                            )
                        }
                        if (rowEffects.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("COMPATIBILITY CHECK", fontWeight = FontWeight.Bold)
                Text("Android version: $androidVersion", color = Muted, fontSize = 12.sp)
                Text("Microphone permission: ${if (hasMicPermission) "Granted" else "Not granted"}", color = if (hasMicPermission) Color(0xFF7BE0A0) else Color(0xFFFF7378), fontSize = 12.sp)
                Text("Selected profile: $selectedEffect", color = Muted, fontSize = 12.sp)
                Button(
                    onClick = {
                        if (!hasMicPermission) {
                            context.requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 5252)
                            status = "Approve microphone permission, then reopen VOICE to recheck."
                        } else {
                            status = "Mic permission is ready. Live routing into other games still requires OEM/system support."
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Red)
                ) { Text(if (hasMicPermission) "CHECK LIVE-GAME SUPPORT" else "GRANT MIC PERMISSION") }
                Text(status, color = Muted, fontSize = 12.sp)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Color(0xFF211416), RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("IMPORTANT ANDROID LIMITATION", color = Color(0xFFFF7378), fontWeight = FontWeight.Bold)
                Text("Android normally does not let a regular app replace the microphone stream used by another game's voice chat. This screen checks basic readiness; it does not claim that the selected effect is being injected into a game. Live in-game voice changing needs compatible OEM/system integration or explicit support from the game.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun UltimateContent(
    context: MainActivity,
    shizukuStatus: String,
    overlayStatus: String,
    onRefreshShizuku: () -> Unit,
    onRequestShizuku: () -> Unit,
    onOverlay: () -> Unit,
    onOpenShizukuGuide: () -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("ULTIMATE MODE", fontWeight = FontWeight.Black, fontSize = 21.sp, color = Red)
            Text("Advanced features are gated behind explicit user-granted permissions.", color = Muted, fontSize = 12.sp)
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("SHIZUKU STATUS", fontWeight = FontWeight.Bold)
                Text(shizukuStatus, color = Muted, fontSize = 13.sp)
                Button(onClick = onRequestShizuku, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                    Text("CONNECT / REQUEST SHIZUKU PERMISSION")
                }
                OutlinedButton(onClick = onRefreshShizuku, modifier = Modifier.fillMaxWidth()) { Text("CHECK AGAIN") }
                Text("Shizuku must be installed and running. On non-rooted devices it uses ADB; Android 11+ supports wireless debugging.", color = Muted, fontSize = 11.sp)
                TextButton(onClick = onOpenShizukuGuide) { Text("Open official Shizuku guide", color = Red) }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("FLOATING GAME OVERLAY", fontWeight = FontWeight.Bold)
                Text(overlayStatus, color = Muted, fontSize = 12.sp)
                Button(onClick = onOverlay, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                    Text("ENABLE / START OVERLAY")
                }
                Text("Android will ask you to allow 'Display over other apps'. Return to BOSS BOOSTER and tap the button again.", color = Muted, fontSize = 11.sp)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CPU / GPU BOOST", fontWeight = FontWeight.Bold)
                Text("Controls are device-specific. Shizuku permission alone does not guarantee access to CPU/GPU frequency controls. This build does not write to kernel frequency nodes or force unsafe clocks.", color = Muted, fontSize = 12.sp)
                Text("Next implementation step: detect supported OEM/game-performance APIs and expose only verified controls for the device.", color = Color(0xFFFF7378), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun StatusCard(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Column(Modifier.then(modifier).background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, contentDescription = null, tint = Red)
        Text(title, color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
        Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    }
}

private fun getLaunchableApps(context: Context): List<LaunchableApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val results = if (Build.VERSION.SDK_INT >= 33) {
        pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
    } else {
        @Suppress("DEPRECATION")
        pm.queryIntentActivities(intent, 0)
    }
    return results.mapNotNull { info ->
        val packageName = info.activityInfo?.packageName ?: return@mapNotNull null
        LaunchableApp(info.loadLabel(pm)?.toString() ?: packageName, packageName)
    }.distinctBy { it.packageName }.filter { it.packageName != context.packageName }.sortedBy { it.label.lowercase() }
}

private fun getDeviceStats(context: Context): DeviceStats {
    val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
    val percent = if (level >= 0 && scale > 0) (level * 100) / scale else 0
    val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
    val temp = if (tempTenths >= 0) "${"%.1f".format(tempTenths / 10.0)}°C" else "Unavailable"
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
    val memory = android.app.ActivityManager.MemoryInfo()
    activityManager.getMemoryInfo(memory)
    val available = memory.availMem / (1024 * 1024)
    val total = memory.totalMem / (1024 * 1024)
    val thermal = if (Build.VERSION.SDK_INT >= 29) {
        val power = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        when (power.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "Normal"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
            else -> "Unavailable"
        }
    } else "Not supported on Android versions below 10"
    return DeviceStats(percent, temp, available, total, thermal)
}
